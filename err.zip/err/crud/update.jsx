
import { useState } from "react";
import axios from "axios";

function App() {
  const [id, setId] = useState("");
  const [name, setName] = useState("");

  function handleUpdate() {
    axios.put(`http://localhost:3000/students/${id}`, {
      id: Number(id),
      name: name
    });

    alert("Student Updated");
  }

  return (
    <div>
      <h2>Update Student</h2>

      <input
        placeholder="Enter Student ID"
        value={id}
        onChange={(e) => setId(e.target.value)}
      />

      <input
        placeholder="Enter New Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <button onClick={handleUpdate}>Update</button>
    </div>
  );
}

export default App;
