
import { useState, useEffect } from "react";
import axios from "axios";

function App() {
  const API = "http://localhost:3000/products";

  const [products, setProducts] = useState([]);
  const [editId, setEditId] = useState(null);

  const [product, setProduct] = useState({
    productName: "",
    category: "",
    price: "",
    quantity: ""
  });

  // GET DATA
  const getProducts = () => {
    axios.get(API).then((res) => {
      setProducts(res.data);
    });
  };

  useEffect(() => {
    getProducts();
  }, []);

  // HANDLE CHANGE
  const handleChange = (e) => {
    setProduct({
      ...product,
      [e.target.name]: e.target.value
    });
  };

  // INSERT DATA
  const handleSubmit = (e) => {
    e.preventDefault();

    if (product.productName === "" ||
        product.category === "" ||
        product.price === "" ||
        product.quantity === "") {
      alert("Please fill all fields");
      return;
    }

    if (Number(product.price) <= 0) {
      alert("Price must be greater than zero");
      return;
    }

    if (Number(product.quantity) < 0 ||
        !Number.isInteger(Number(product.quantity))) {
      alert("Enter valid quantity");
      return;
    }

    const data = {
      ...product,
      price: Number(product.price),
      quantity: Number(product.quantity)
    };

    axios.post(API, data).then(() => {
      alert("Product Added");
      getProducts();
      setProduct({
        productName: "",
        category: "",
        price: "",
        quantity: ""
      });
    });
  };

  // EDIT DATA
  const handleEdit = (p) => {
    setProduct({
      productName: p.productName,
      category: p.category,
      price: String(p.price),
      quantity: String(p.quantity)
    });
    setEditId(p.id);
  };

  // UPDATE DATA
  const handleUpdate = () => {
    if (!editId) {
      alert("Please select a product to edit");
      return;
    }

    const data = {
      ...product,
      price: Number(product.price),
      quantity: Number(product.quantity)
    };

    axios.put(API + "/" + editId, data).then(() => {
      alert("Product Updated");
      getProducts();
      setProduct({
        productName: "",
        category: "",
        price: "",
        quantity: ""
      });
      setEditId(null);
    });
  };

  // DELETE DATA
  const handleDelete = (id) => {
    if (window.confirm("Delete product?")) {
      axios.delete(API + "/" + id).then(() => {
        alert("Deleted");
        getProducts();
      });
    }
  };

  return (
    <div>
      <h2>Product Management</h2>

      <form onSubmit={handleSubmit}>
        <input name="productName" placeholder="Product Name"
          value={product.productName} onChange={handleChange} />

        <select name="category" value={product.category}
          onChange={handleChange}>
          <option value="">Select Category</option>
          <option value="Electronics">Electronics</option>
          <option value="Books">Books</option>
          <option value="Clothing">Clothing</option>
        </select>

        <input type="number" name="price" placeholder="Price"
          value={product.price} onChange={handleChange} />

        <input type="number" name="quantity" placeholder="Quantity"
          value={product.quantity} onChange={handleChange} />

        <button type="submit">Add</button>
        <button type="button" onClick={handleUpdate}>
          Update
        </button>
      </form>

      <table border="1">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {products.map((p) => (
            <tr key={p.id}>
              <td>{p.id}</td>
              <td>{p.productName}</td>
              <td>{p.category}</td>
              <td>{p.price}</td>
              <td>{p.quantity}</td>
              <td>
                <button onClick={() => handleEdit(p)}>
                  Edit
                </button>
                <button onClick={() => handleDelete(p.id)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
