
import { useState, useEffect } from "react";
import axios from "axios";

function App() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3000/students")
      .then((res) => {
        setStudents(res.data);
      });
  }, []);

  return (
    <div>
      <h2>Student List</h2>

      {students.map((s) => (
        <p key={s.id}>
          {s.name} - {s.email}
        </p>
      ))}
    </div>
  );
}

export default App;
