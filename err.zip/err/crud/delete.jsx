
import axios from "axios";

function App() {
  function handleDelete(id) {
    if (window.confirm("Are you sure?")) {
      axios.delete(`http://localhost:3000/students/${id}`);
      alert("Student Deleted");
    }
  }

  return (
    <div>
      <h2>Delete Student</h2>

      <button onClick={() => handleDelete(1)}>
        Delete Student ID 1
      </button>
    </div>
  );
}

export default App;
