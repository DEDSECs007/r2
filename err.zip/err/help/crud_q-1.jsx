
import { useState, useEffect } from "react";
import axios from "axios";

function App() {
  const API = "http://localhost:3000/students";

  const [students, setStudents] = useState([]);
  const [editId, setEditId] = useState(null);

  const [student, setStudent] = useState({
    name: "",
    email: "",
    course: ""
  });

  // GET DATA
  const getStudents = () => {
    axios.get(API).then((res) => {
      setStudents(res.data);
    });
  };

  useEffect(() => {
    getStudents();
  }, []);

  // HANDLE CHANGE
  const handleChange = (e) => {
    setStudent({
      ...student,
      [e.target.name]: e.target.value
    });
  };

  // INSERT DATA
  const handleSubmit = (e) => {
    e.preventDefault();

    if (student.name === "" || student.email === "" ||
        student.course === "") {
      alert("Please fill all fields");
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(student.email)) {
      alert("Enter valid email");
      return;
    }

    axios.post(API, student).then(() => {
      alert("Student Added");
      getStudents();
      setStudent({ name: "", email: "", course: "" });
    });
  };

  // EDIT DATA
  const handleEdit = (s) => {
    setStudent({
      name: s.name,
      email: s.email,
      course: s.course
    });
    setEditId(s.id);
  };

  // UPDATE DATA
  const handleUpdate = () => {
    if (!editId) {
      alert("Please select a student to edit");
      return;
    }

    axios.put(API + "/" + editId, student).then(() => {
      alert("Student Updated");
      getStudents();
      setStudent({ name: "", email: "", course: "" });
      setEditId(null);
    });
  };

  // DELETE DATA
  const handleDelete = (id) => {
    if (window.confirm("Delete student?")) {
      axios.delete(API + "/" + id).then(() => {
        alert("Deleted");
        getStudents();
      });
    }
  };

  return (
    <div>
      <h2>Student Management</h2>

      <form onSubmit={handleSubmit}>
        <input
          name="name"
          placeholder="Name"
          value={student.name}
          onChange={handleChange}
        />

        <input
          name="email"
          placeholder="Email"
          value={student.email}
          onChange={handleChange}
        />

        <select name="course" value={student.course}
          onChange={handleChange}>
          <option value="">Select Course</option>
          <option value="B.Sc IT">B.Sc IT</option>
          <option value="BCA">BCA</option>
          <option value="BBA">BBA</option>
        </select>

        <button type="submit">Add</button>
        <button type="button" onClick={handleUpdate}>
          Update
        </button>
      </form>

      <table border="1">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Course</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {students.map((s) => (
            <tr key={s.id}>
              <td>{s.id}</td>
              <td>{s.name}</td>
              <td>{s.email}</td>
              <td>{s.course}</td>
              <td>
                <button onClick={() => handleEdit(s)}>
                  Edit
                </button>
                <button onClick={() => handleDelete(s.id)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
