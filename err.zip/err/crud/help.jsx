function Navbar() {
  return (
    <div>
      <h2>My Website</h2>
      <a href="/">Home</a> |
      <a href="/about"> About</a>
    </div>
  );
}

export default Navbar;

function Header() {
  return <h1>Welcome to React</h1>;
}

export default Header;

function Footer() {
  return <h3>Copyright 2026</h3>;
}

export default Footer;

function Home() {
  return (
    <div>
      <h2>Home Page</h2>
      <p>Welcome to my website</p>
    </div>
  );
}

export default Home;

function Student(props) {
  return (
    <div>
      <h2>{props.name}</h2>
      <p>{props.roll}</p>
      <p>{props.course}</p>
    </div>
  );
}

export default Student;

Use in App.jsx:
import Student from "./Student";

function App() {
  return (
    <div>
      <Student name="Rahul" roll="101" course="B.Sc IT" />
      <Student name="Priya" roll="102" course="BCA" />
    </div>
  );
}

export default App;

import { useState } from "react";

function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div>
      <h2>{count}</h2>

      <button onClick={() => setCount(count + 1)}>
        Increment
      </button>

      <button onClick={() => setCount(count - 1)}>
        Decrement
      </button>
    </div>
  );
}

export default Counter;

function App() {
  const fruits = ["Apple", "Mango", "Banana"];

  return (
    <div>
      {fruits.map((item) => (
        <p key={item}>{item}</p>
      ))}
    </div>
  );
}

export default App;

// 8. React Router — Important
Install:
npm install react-router-dom


App.jsx:
import {
  BrowserRouter,
  Routes,
  Route,
  Link
} from "react-router-dom";

function Home() {
  return <h2>Home Page</h2>;
}

function About() {
  return <h2>About Page</h2>;
}

function App() {
  return (
    <BrowserRouter>
      <Link to="/">Home</Link> |
      <Link to="/about">About</Link>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;


// 9. Axios GET — Simple
import { useState, useEffect } from "react";
import axios from "axios";

function App() {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3000/students")
      .then((res) => setData(res.data));
  }, []);

  return (
    <div>
      {data.map((item) => (
        <p key={item.id}>{item.name}</p>
      ))}
    </div>
  );
}

export default App;


// 10. JSON Example
{
  "students": [
    {
      "id": "1",
      "name": "Rahul",
      "course": "B.Sc IT"
    },
    {
      "id": "2",
      "name": "Priya",
      "course": "BCA"
    }
  ]
}